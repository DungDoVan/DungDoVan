#!/bin/sh

go test ./reviews/ ./users/ ./passwords/
