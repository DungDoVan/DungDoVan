#!/usr/bin/env bash

docker build -t designapis/farmstall:latest .

echo Done
